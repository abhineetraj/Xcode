//
//  FirstViewController.swift
//  To Do list
//
//  Created by Abhineet Raj on 11/3/15.
//  Copyright © 2015 Clinz Organization. All rights reserved.
//

import UIKit

var toDoList = [String]()// variable is defined here outside the first view controller so that is is available to all the viewcontroller within the app.

class FirstViewController: UIViewController,UITableViewDelegate // Table view delegate is a class to refer to the table used in the app. We also right click on table and drag it to view controller button for delegate and source. This allows the viewcontroller to control the table

{

    @IBOutlet var toDoListTable: UITableView!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
       
        if (NSUserDefaults.standardUserDefaults().objectForKey("toDoList") != nil) { // Condition to execute the next set of codes only if the table has any value
        
        toDoList = NSUserDefaults.standardUserDefaults().objectForKey("toDoList") as! [String] // stores values permanently
        }
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

  
    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int
    {
        return toDoList.count
    }
    
    
    
    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell
    
    {
    let cell = UITableViewCell(style: UITableViewCellStyle.Default, reuseIdentifier: "Cell") // Prototype cell should be created in first view controller
        
        cell.textLabel?.text = toDoList[indexPath.row] // index path.row will keep passing the row number to array to do list. Be careful with square brackets
        
    return cell
    
    }

    override func viewDidAppear(animated: Bool) { // to update the value of this view to table during switch
    
        if ([toDoList] != nil)
        {
        toDoListTable.reloadData()
        }
        
        
    }
    
    
    
    
    
    
    
    
    
    
    
    
    
}

